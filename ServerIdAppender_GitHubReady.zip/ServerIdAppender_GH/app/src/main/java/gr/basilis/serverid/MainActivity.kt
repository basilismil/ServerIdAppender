package gr.basilis.serverid

import android.content.ContentResolver
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.opencsv.CSVReaderBuilder
import com.opencsv.CSVWriterBuilder
import com.opencsv.ICSVWriter
import org.apache.poi.ss.usermodel.*
import org.apache.poi.xssf.usermodel.XSSFWorkbook
import java.io.*
import java.util.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AppUI(contentResolver) }
    }
}

private enum class SaveFormat(val mime: String, val ext: String) {
    CSV("text/csv", "csv"),
    XLSX("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "xlsx")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AppUI(cr: ContentResolver) {
    var status by remember { mutableStateOf("Κανένα αρχείο προς το παρόν.") }
    var processed by remember { mutableStateOf<ProcessedTable?>(null) }
    var saveFormat by remember { mutableStateOf(SaveFormat.CSV) }

    val pickDoc = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        uri?.let {
            try {
                val mime = cr.getType(it) ?: ""
                val table = when {
                    mime.contains("spreadsheet") || it.toString().endsWith(".xlsx", true) -> readXlsx(cr, it)
                    mime.contains("csv") || it.toString().endsWith(".csv", true) -> readCsv(cr, it)
                    else -> readCsv(cr, it)
                }
                processed = ensureServerId(table)
                status = "OK: ${processed!!.rows.size} γραμμές, ${processed!!.headers.joinToString()}"
            } catch (e: Exception) {
                status = "Σφάλμα ανάγνωσης: ${e.message}"
            }
        }
    }

    val createDoc = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument()
    ) { uri ->
        if (uri != null && processed != null) {
            try {
                when (saveFormat) {
                    SaveFormat.CSV -> writeCsv(cr, uri, processed!!)
                    SaveFormat.XLSX -> writeXlsx(cr, uri, processed!!)
                }
                status = "Αποθηκεύτηκε επιτυχώς στο $uri"
            } catch (e: Exception) {
                status = "Σφάλμα αποθήκευσης: ${e.message}"
            }
        }
    }

    Scaffold(topBar = { TopAppBar(title = { Text("Server ID Appender") }) }) { padding ->
        Column(
            modifier = Modifier.padding(padding).padding(16.dp).fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                "Διάλεξε CSV/XLSX, διασφάλισε στήλη server_id, και αποθήκευσε σε CSV/XLSX.",
                textAlign = TextAlign.Center
            )
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(onClick = {
                    pickDoc.launch(arrayOf(
                        "text/csv",
                        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                    ))
                }) { Text("Επέλεξε αρχείο") }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = saveFormat == SaveFormat.CSV, onClick = { saveFormat = SaveFormat.CSV }, label = { Text("CSV") })
                    FilterChip(selected = saveFormat == SaveFormat.XLSX, onClick = { saveFormat = SaveFormat.XLSX }, label = { Text("XLSX") })
                }

                Button(enabled = processed != null, onClick = { createDoc.launch(saveFormat.mime) }) {
                    Text("Αποθήκευση Αρχείου")
                }
            }
            Text(status)
        }
    }
}

private data class ProcessedTable(
    val headers: MutableList<String>,
    val rows: MutableList<MutableList<String>>
)

private fun ensureServerId(table: ProcessedTable): ProcessedTable {
    val idx = table.headers.indexOfFirst { it.equals("server_id", true) || it.equals("server id", true) || it.equals("serverID", true) }
    val colIndex = if (idx >= 0) idx else run {
        table.headers.add("server_id")
        table.rows.forEach { it.add("") }
        table.headers.lastIndex
    }
    for (row in table.rows) {
        if (colIndex >= row.size) {
            while (row.size <= colIndex) row.add("")
        }
        if (row[colIndex].isBlank()) {
            row[colIndex] = UUID.randomUUID().toString().replace("-", "").lowercase()
        }
    }
    return table
}

private fun readCsv(cr: ContentResolver, uri: Uri): ProcessedTable {
    cr.openInputStream(uri).use { input ->
        requireNotNull(input) { "Δεν μπόρεσα να ανοίξω το αρχείο." }
        val reader = input.reader(Charsets.UTF_8)
        val csvReader = CSVReaderBuilder(reader).withSkipLines(0).build()
        val all = csvReader.readAll()
        require(all.isNotEmpty()) { "Κενό CSV." }
        val headers = all.first().map { it?.trim() ?: "" }.toMutableList()
        val rows = all.drop(1).map { line ->
            val list = line.map { it?.trim() ?: "" }.toMutableList()
            while (list.size < headers.size) list.add("")
            list
        }.toMutableList()
        return ProcessedTable(headers, rows)
    }
}

private fun writeCsv(cr: ContentResolver, uri: Uri, table: ProcessedTable) {
    cr.openOutputStream(uri, "w").use { output ->
        requireNotNull(output) { "Δεν μπόρεσα να γράψω στο αρχείο." }
        val writer = output.writer(Charsets.UTF_8)
        val csvWriter: ICSVWriter = CSVWriterBuilder(writer).withSeparator(',').build()
        csvWriter.writeNext(table.headers.toTypedArray())
        for (row in table.rows) csvWriter.writeNext(row.toTypedArray())
        csvWriter.close()
    }
}

private fun readXlsx(cr: ContentResolver, uri: Uri): ProcessedTable {
    cr.openInputStream(uri).use { input ->
        requireNotNull(input) { "Δεν μπόρεσα να ανοίξω το αρχείο." }
        val wb = XSSFWorkbook(input)
        val sheet = wb.getSheetAt(0)
        val iterator = sheet.iterator()
        require(iterator.hasNext()) { "Κενό φύλλο εργασίας." }
        val headerRow = iterator.next()
        val headers = mutableListOf<String>()
        for (c in 0 until headerRow.lastCellNum) {
            headers.add(headerRow.getCell(c)?.stringCellValue?.trim() ?: "")
        }
        val rows = mutableListOf<MutableList<String>>()
        while (iterator.hasNext()) {
            val r = iterator.next()
            val list = MutableList(headers.size) { "" }
            for (c in 0 until headers.size) {
                val cell = r.getCell(c)
                list[c] = cell?.let { cellToString(it) } ?: ""
            }
            rows.add(list)
        }
        wb.close()
        return ProcessedTable(headers, rows)
    }
}

private fun writeXlsx(cr: ContentResolver, uri: Uri, table: ProcessedTable) {
    val wb: Workbook = XSSFWorkbook()
    val sheet = wb.createSheet("Sheet1")
    var rowIdx = 0
    val header = sheet.createRow(rowIdx++)
    table.headers.forEachIndexed { i, h -> header.createCell(i).setCellValue(h) }
    table.rows.forEach { dataRow ->
        val r = sheet.createRow(rowIdx++)
        dataRow.forEachIndexed { i, v -> r.createCell(i).setCellValue(v) }
    }
    cr.openOutputStream(uri, "w").use { output ->
        requireNotNull(output) { "Δεν μπόρεσα να γράψω στο αρχείο." }
        wb.write(output); wb.close()
    }
}

private fun cellToString(cell: Cell): String = when (cell.cellType) {
    CellType.STRING -> cell.stringCellValue
    CellType.NUMERIC -> if (DateUtil.isCellDateFormatted(cell)) cell.dateCellValue.time.toString() else cell.numericCellValue.toLong().toString()
    CellType.BOOLEAN -> cell.booleanCellValue.toString()
    CellType.FORMULA -> cell.richStringCellValue.string
    else -> ""
}
